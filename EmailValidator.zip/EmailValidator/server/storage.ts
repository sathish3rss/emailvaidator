import { emailValidations, type EmailValidation, type InsertEmailValidation } from "@shared/schema";

export interface IStorage {
  getUser(id: number): Promise<any | undefined>;
  getUserByUsername(username: string): Promise<any | undefined>;
  createUser(user: any): Promise<any>;
  createEmailValidation(validation: InsertEmailValidation): Promise<EmailValidation>;
  getEmailValidationsByEmail(email: string): Promise<EmailValidation[]>;
  getAllEmailValidations(): Promise<EmailValidation[]>;
}

export class MemStorage implements IStorage {
  private users: Map<number, any>;
  private emailValidations: Map<number, EmailValidation>;
  private currentUserId: number;
  private currentValidationId: number;

  constructor() {
    this.users = new Map();
    this.emailValidations = new Map();
    this.currentUserId = 1;
    this.currentValidationId = 1;
  }

  async getUser(id: number): Promise<any | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<any | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: any): Promise<any> {
    const id = this.currentUserId++;
    const user: any = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async createEmailValidation(insertValidation: InsertEmailValidation): Promise<EmailValidation> {
    const id = this.currentValidationId++;
    const validation: EmailValidation = {
      ...insertValidation,
      id,
      validatedAt: new Date(),
      mxRecords: insertValidation.mxRecords || null,
      errorMessage: insertValidation.errorMessage || null,
    };
    this.emailValidations.set(id, validation);
    return validation;
  }

  async getEmailValidationsByEmail(email: string): Promise<EmailValidation[]> {
    return Array.from(this.emailValidations.values()).filter(
      (validation) => validation.email === email,
    );
  }

  async getAllEmailValidations(): Promise<EmailValidation[]> {
    return Array.from(this.emailValidations.values());
  }
}

export const storage = new MemStorage();
