import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { validateEmailRequestSchema, validateBulkEmailsRequestSchema } from "@shared/schema";
import { z } from "zod";
import dns from "dns";
import net from "net";
import { promisify } from "util";

const resolveMx = promisify(dns.resolveMx);

// Email format validation regex
const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;

// Common invalid local parts that are typically not real email addresses
const suspiciousLocalParts = [
  'hello', 'test', 'admin', 'info', 'support', 'sales', 'marketing', 
  'noreply', 'no-reply', 'webmaster', 'postmaster', 'abuse', 'security',
  'mail', 'email', 'contact', 'help', 'service', 'user', 'demo', 'sample'
];

async function validateEmailFormat(email: string): Promise<boolean> {
  return emailRegex.test(email);
}

async function checkEmailRealism(email: string): Promise<{ isRealistic: boolean; reason?: string }> {
  const [localPart, domain] = email.split('@');
  
  // Check for obviously fake or generic email addresses
  const lowerLocalPart = localPart.toLowerCase();
  
  // Check if it's a very generic/suspicious local part for major providers
  const majorProviders = ['gmail.com', 'yahoo.com', 'outlook.com', 'hotmail.com', 'aol.com'];
  if (majorProviders.includes(domain.toLowerCase()) && suspiciousLocalParts.includes(lowerLocalPart)) {
    return {
      isRealistic: false,
      reason: `Generic email address '${lowerLocalPart}@${domain}' is likely not a real mailbox`
    };
  }
  
  // Check for very short local parts (less than 3 characters) on major providers
  if (majorProviders.includes(domain.toLowerCase()) && localPart.length < 3) {
    return {
      isRealistic: false,
      reason: `Very short local part '${localPart}' on major provider is likely invalid`
    };
  }
  
  // Check for suspicious patterns
  if (/^(test|hello|admin|info)(\d+)?$/i.test(localPart)) {
    return {
      isRealistic: false,
      reason: `Local part '${localPart}' appears to be a test or generic address`
    };
  }
  
  return { isRealistic: true };
}

async function checkMxRecords(domain: string): Promise<{ hasMx: boolean; mxRecords: string[] }> {
  try {
    const mxRecords = await resolveMx(domain);
    return {
      hasMx: mxRecords && mxRecords.length > 0,
      mxRecords: mxRecords ? mxRecords.map(record => record.exchange) : [],
    };
  } catch (error) {
    return {
      hasMx: false,
      mxRecords: [],
    };
  }
}

async function checkSmtpExists(email: string, mxRecord: string): Promise<{ exists: boolean; reason?: string }> {
  return new Promise((resolve) => {
    const timeout = 10000; // 10 seconds timeout
    let resolved = false;
    
    const socket = new net.Socket();
    
    const cleanup = () => {
      if (!resolved) {
        resolved = true;
        socket.destroy();
      }
    };
    
    const timeoutId = setTimeout(() => {
      cleanup();
      resolve({ exists: false, reason: "SMTP connection timeout" });
    }, timeout);
    
    socket.setTimeout(timeout);
    
    socket.connect(25, mxRecord, () => {
      let step = 0;
      let response = '';
      
      const commands = [
        `HELO ${mxRecord}`,
        'MAIL FROM: <test@example.com>',
        `RCPT TO: <${email}>`,
        'QUIT'
      ];
      
      const sendCommand = (cmd: string) => {
        socket.write(cmd + '\r\n');
      };
      
      socket.on('data', (data) => {
        response += data.toString();
        const lines = response.split('\r\n');
        
        for (const line of lines) {
          if (!line) continue;
          
          const code = parseInt(line.substring(0, 3));
          
          if (step === 0 && code === 220) {
            // Connected, send HELO
            sendCommand(commands[0]);
            step = 1;
          } else if (step === 1 && code === 250) {
            // HELO accepted, send MAIL FROM
            sendCommand(commands[1]);
            step = 2;
          } else if (step === 2 && code === 250) {
            // MAIL FROM accepted, send RCPT TO
            sendCommand(commands[2]);
            step = 3;
          } else if (step === 3) {
            // RCPT TO response - this is what we're looking for
            clearTimeout(timeoutId);
            cleanup();
            
            if (code === 250) {
              resolve({ exists: true });
            } else if (code === 550) {
              resolve({ exists: false, reason: "Email address does not exist" });
            } else if (code === 553) {
              resolve({ exists: false, reason: "Invalid email address" });
            } else if (code === 552) {
              resolve({ exists: false, reason: "Mailbox full" });
            } else {
              resolve({ exists: false, reason: `SMTP error: ${line}` });
            }
            return;
          }
        }
        
        response = lines[lines.length - 1]; // Keep the last incomplete line
      });
    });
    
    socket.on('error', (error) => {
      clearTimeout(timeoutId);
      cleanup();
      resolve({ exists: false, reason: `SMTP connection error: ${error.message}` });
    });
    
    socket.on('timeout', () => {
      clearTimeout(timeoutId);
      cleanup();
      resolve({ exists: false, reason: "SMTP connection timeout" });
    });
  });
}

async function validateSingleEmail(email: string) {
  const isFormatValid = await validateEmailFormat(email);
  
  if (!isFormatValid) {
    return {
      email,
      isFormatValid: false,
      hasMxRecord: false,
      mxRecords: [],
      smtpExists: false,
      isValid: false,
      errorMessage: "Invalid email format",
    };
  }

  const domain = email.split('@')[1];
  const { hasMx, mxRecords } = await checkMxRecords(domain);
  
  if (!hasMx || mxRecords.length === 0) {
    return {
      email,
      isFormatValid,
      hasMxRecord: false,
      mxRecords,
      smtpExists: false,
      isValid: false,
      errorMessage: "No MX records found for domain",
    };
  }

  // Perform SMTP verification on the primary MX record
  const primaryMxRecord = mxRecords[0];
  const { exists: smtpExists, reason: smtpReason } = await checkSmtpExists(email, primaryMxRecord);

  // Check if email seems realistic (fallback for when SMTP is inconclusive)
  const { isRealistic, reason: realismReason } = await checkEmailRealism(email);

  // Email is valid if format is correct, MX records exist, AND SMTP verification passes
  let isValid = isFormatValid && hasMx && smtpExists;
  
  // If SMTP is inconclusive but email seems unrealistic, mark as invalid
  if (!smtpExists && !isRealistic) {
    isValid = false;
  }

  let errorMessage: string | undefined = undefined;
  if (!isValid) {
    if (!isFormatValid) {
      errorMessage = "Invalid email format";
    } else if (!hasMx) {
      errorMessage = "No MX records found for domain";
    } else if (!smtpExists) {
      errorMessage = smtpReason || "Email address does not exist";
    } else if (!isRealistic) {
      errorMessage = realismReason || "Email appears to be invalid or unrealistic";
    }
  }

  return {
    email,
    isFormatValid,
    hasMxRecord: hasMx,
    mxRecords,
    smtpExists,
    isValid,
    errorMessage,
  };
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Single email validation endpoint
  app.post("/api/validate-email", async (req, res) => {
    try {
      const { email } = validateEmailRequestSchema.parse(req.body);
      
      const validation = await validateSingleEmail(email);
      const savedValidation = await storage.createEmailValidation(validation);
      
      res.json(savedValidation);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          message: "Invalid request", 
          errors: error.errors 
        });
      }
      
      console.error("Email validation error:", error);
      res.status(500).json({ 
        message: "Internal server error during email validation" 
      });
    }
  });

  // Bulk email validation endpoint
  app.post("/api/validate-bulk-emails", async (req, res) => {
    try {
      const { emails } = validateBulkEmailsRequestSchema.parse(req.body);
      
      const validations = await Promise.all(
        emails.map(async (email) => {
          const validation = await validateSingleEmail(email);
          return await storage.createEmailValidation(validation);
        })
      );
      
      res.json({ validations });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          message: "Invalid request", 
          errors: error.errors 
        });
      }
      
      console.error("Bulk email validation error:", error);
      res.status(500).json({ 
        message: "Internal server error during bulk email validation" 
      });
    }
  });

  // Get validation history
  app.get("/api/validations", async (req, res) => {
    try {
      const validations = await storage.getAllEmailValidations();
      res.json(validations);
    } catch (error) {
      console.error("Get validations error:", error);
      res.status(500).json({ 
        message: "Internal server error fetching validations" 
      });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
