import { useState } from "react";
import SingleEmailValidator from "@/components/single-email-validator";
import ValidationResults from "@/components/validation-results";
import BulkEmailValidator from "@/components/bulk-email-validator";
import BulkValidationResults from "@/components/bulk-validation-results";
import LoadingOverlay from "@/components/loading-overlay";
import { CheckCircle, Zap, Package, Shield } from "lucide-react";

export default function EmailValidator() {
  const [singleValidation, setSingleValidation] = useState(null);
  const [bulkValidations, setBulkValidations] = useState([]);
  const [isLoading, setIsLoading] = useState(false);

  return (
    <div className="bg-gray-50 font-sans min-h-screen">
      {/* Header Section */}
      <header className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-6">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center">
                  <CheckCircle className="w-6 h-6 text-white" />
                </div>
              </div>
              <div className="ml-4">
                <h1 className="text-2xl font-bold text-gray-900">Email Validator</h1>
                <p className="text-sm text-gray-600">Format, MX & SMTP Verification</p>
              </div>
            </div>
            <div className="hidden md:flex items-center space-x-4">
              <span className="text-sm text-gray-500">Fast • Accurate • Reliable</span>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Single Email Validation Section */}
        <div className="mb-8">
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <div className="mb-6">
              <h2 className="text-lg font-semibold text-gray-900 mb-2">Single Email Validation</h2>
              <p className="text-sm text-gray-600">Enter an email address to validate format, MX records, and SMTP existence</p>
            </div>

            <SingleEmailValidator 
              onValidation={setSingleValidation}
              setLoading={setIsLoading}
            />

            {singleValidation && (
              <ValidationResults validation={singleValidation} />
            )}
          </div>
        </div>

        {/* Bulk Email Validation Section */}
        <div className="mb-8">
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <div className="mb-6">
              <h2 className="text-lg font-semibold text-gray-900 mb-2">Bulk Email Validation</h2>
              <p className="text-sm text-gray-600">Validate multiple email addresses at once - paste one email per line</p>
            </div>

            <BulkEmailValidator 
              onValidation={setBulkValidations}
              setLoading={setIsLoading}
            />

            {bulkValidations.length > 0 && (
              <BulkValidationResults validations={bulkValidations} />
            )}
          </div>
        </div>

        {/* Features Section */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <div className="bg-white rounded-lg border border-gray-200 p-6 text-center">
            <div className="w-12 h-12 mx-auto bg-blue-100 rounded-lg flex items-center justify-center mb-4">
              <Zap className="w-6 h-6 text-blue-600" />
            </div>
            <h3 className="text-lg font-semibold text-gray-900 mb-2">Fast Validation</h3>
            <p className="text-sm text-gray-600">Lightning-fast email format and MX record verification</p>
          </div>

          <div className="bg-white rounded-lg border border-gray-200 p-6 text-center">
            <div className="w-12 h-12 mx-auto bg-emerald-100 rounded-lg flex items-center justify-center mb-4">
              <CheckCircle className="w-6 h-6 text-emerald-600" />
            </div>
            <h3 className="text-lg font-semibold text-gray-900 mb-2">Accurate Results</h3>
            <p className="text-sm text-gray-600">Professional-grade SMTP verification ensures email addresses actually exist</p>
          </div>

          <div className="bg-white rounded-lg border border-gray-200 p-6 text-center">
            <div className="w-12 h-12 mx-auto bg-amber-100 rounded-lg flex items-center justify-center mb-4">
              <Package className="w-6 h-6 text-amber-600" />
            </div>
            <h3 className="text-lg font-semibold text-gray-900 mb-2">Bulk Processing</h3>
            <p className="text-sm text-gray-600">Validate hundreds of emails simultaneously with ease</p>
          </div>

          <div className="bg-white rounded-lg border border-gray-200 p-6 text-center">
            <div className="w-12 h-12 mx-auto bg-purple-100 rounded-lg flex items-center justify-center mb-4">
              <Shield className="w-6 h-6 text-purple-600" />
            </div>
            <h3 className="text-lg font-semibold text-gray-900 mb-2">No External APIs</h3>
            <p className="text-sm text-gray-600">Built-in DNS resolution ensures privacy and reliability</p>
          </div>
        </div>
      </main>

      <LoadingOverlay isVisible={isLoading} />
    </div>
  );
}
