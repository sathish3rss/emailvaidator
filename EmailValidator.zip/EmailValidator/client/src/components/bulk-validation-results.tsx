import { useState } from "react";
import { Button } from "@/components/ui/button";
import { CheckCircle, XCircle, Download, Copy } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface BulkValidationResultsProps {
  validations: Array<{
    email: string;
    isFormatValid: boolean;
    hasMxRecord: boolean;
    smtpExists: boolean;
    isValid: boolean;
    errorMessage?: string;
  }>;
}

export default function BulkValidationResults({ validations }: BulkValidationResultsProps) {
  const { toast } = useToast();
  
  const validEmails = validations.filter(v => v.isValid);
  const invalidEmails = validations.filter(v => !v.isValid);

  const handleCopyToClipboard = async () => {
    const validEmailsList = validEmails.map(v => v.email).join('\n');
    try {
      await navigator.clipboard.writeText(validEmailsList);
      toast({
        title: "Copied to Clipboard",
        description: `${validEmails.length} valid emails copied to clipboard`,
      });
    } catch (error) {
      toast({
        title: "Copy Failed",
        description: "Failed to copy emails to clipboard",
        variant: "destructive",
      });
    }
  };

  const handleExportCSV = () => {
    const csvContent = [
      "Email,Format Valid,MX Found,SMTP Exists,Valid,Error Message",
      ...validations.map(v => 
        `"${v.email}",${v.isFormatValid},${v.hasMxRecord},${v.smtpExists},${v.isValid},"${v.errorMessage || ''}"`
      )
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', `email-validation-results-${new Date().toISOString().split('T')[0]}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    toast({
      title: "Export Complete",
      description: "Validation results exported to CSV file",
    });
  };

  return (
    <div className="mt-6">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold text-gray-900">Validation Results</h3>
        <div className="flex items-center space-x-4 text-sm">
          <span className="flex items-center text-emerald-600">
            <CheckCircle className="w-4 h-4 mr-1" />
            {validEmails.length} Valid
          </span>
          <span className="flex items-center text-red-600">
            <XCircle className="w-4 h-4 mr-1" />
            {invalidEmails.length} Invalid
          </span>
        </div>
      </div>

      <div className="space-y-3">
        {validations.map((validation, index) => (
          <div key={index} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg border border-gray-200">
            <div className="flex items-center space-x-3">
              <div className="flex-shrink-0">
                {validation.isValid ? (
                  <CheckCircle className="w-5 h-5 text-emerald-500" />
                ) : (
                  <XCircle className="w-5 h-5 text-red-500" />
                )}
              </div>
              <div>
                <p className="text-sm font-medium text-gray-900">{validation.email}</p>
                <p className="text-xs text-gray-500">
                  Format {validation.isFormatValid ? '✓' : '✗'} • 
                  MX {validation.hasMxRecord ? '✓' : '✗'} • 
                  SMTP {validation.smtpExists ? '✓' : '✗'}
                </p>
                {validation.errorMessage && (
                  <p className="text-xs text-red-600 mt-1">{validation.errorMessage}</p>
                )}
              </div>
            </div>
            <div className="flex items-center space-x-2">
              <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                validation.isValid 
                  ? 'bg-emerald-100 text-emerald-800' 
                  : 'bg-red-100 text-red-800'
              }`}>
                {validation.isValid ? 'Valid' : 'Invalid'}
              </span>
            </div>
          </div>
        ))}
      </div>

      {/* Export Results */}
      <div className="mt-6 flex flex-col sm:flex-row gap-3">
        <Button
          onClick={handleExportCSV}
          variant="outline"
          className="inline-flex items-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
        >
          <Download className="w-4 h-4 mr-2" />
          Export Valid Emails
        </Button>
        <Button
          onClick={handleCopyToClipboard}
          variant="outline"
          className="inline-flex items-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
        >
          <Copy className="w-4 h-4 mr-2" />
          Copy to Clipboard
        </Button>
      </div>
    </div>
  );
}
