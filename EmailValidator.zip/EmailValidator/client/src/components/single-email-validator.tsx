import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { CheckCircle, AlertCircle } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface SingleEmailValidatorProps {
  onValidation: (validation: any) => void;
  setLoading: (loading: boolean) => void;
}

export default function SingleEmailValidator({ onValidation, setLoading }: SingleEmailValidatorProps) {
  const [email, setEmail] = useState("");
  const [realtimeValid, setRealtimeValid] = useState<boolean | null>(null);
  const { toast } = useToast();

  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;

  const validateEmailMutation = useMutation({
    mutationFn: async (emailAddress: string) => {
      const response = await apiRequest("POST", "/api/validate-email", { email: emailAddress });
      return response.json();
    },
    onSuccess: (data) => {
      onValidation(data);
      setLoading(false);
      toast({
        title: "Validation Complete",
        description: `Email ${data.isValid ? 'is valid' : 'is invalid'}`,
      });
    },
    onError: (error) => {
      setLoading(false);
      toast({
        title: "Validation Failed",
        description: "Failed to validate email. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleEmailChange = (value: string) => {
    setEmail(value);
    if (value.trim()) {
      setRealtimeValid(emailRegex.test(value));
    } else {
      setRealtimeValid(null);
    }
  };

  const handleValidate = () => {
    if (!email.trim()) {
      toast({
        title: "Email Required",
        description: "Please enter an email address to validate.",
        variant: "destructive",
      });
      return;
    }

    if (!emailRegex.test(email)) {
      toast({
        title: "Invalid Format",
        description: "Please enter a valid email format.",
        variant: "destructive",
      });
      return;
    }

    setLoading(true);
    validateEmailMutation.mutate(email);
  };

  return (
    <div className="space-y-4">
      <div className="relative">
        <Label htmlFor="single-email" className="block text-sm font-medium text-gray-700 mb-2">
          Email Address
        </Label>
        <div className="relative">
          <Input
            type="email"
            id="single-email"
            placeholder="example@domain.com"
            value={email}
            onChange={(e) => handleEmailChange(e.target.value)}
            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-colors duration-200 pr-12"
          />
          <div className="absolute inset-y-0 right-0 pr-3 flex items-center">
            {realtimeValid === true && (
              <CheckCircle className="w-5 h-5 text-emerald-500" />
            )}
            {realtimeValid === false && (
              <AlertCircle className="w-5 h-5 text-red-500" />
            )}
          </div>
        </div>
      </div>

      <Button
        onClick={handleValidate}
        disabled={validateEmailMutation.isPending}
        className="w-full sm:w-auto bg-blue-600 hover:bg-blue-700 text-white font-medium py-3 px-6 rounded-lg transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
      >
        {validateEmailMutation.isPending ? "Validating..." : "Validate Email"}
      </Button>
    </div>
  );
}
