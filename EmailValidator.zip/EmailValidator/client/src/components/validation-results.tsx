import { CheckCircle, XCircle } from "lucide-react";

interface ValidationResultsProps {
  validation: {
    isFormatValid: boolean;
    hasMxRecord: boolean;
    mxRecords: string[];
    smtpExists: boolean;
    isValid: boolean;
    errorMessage?: string;
  };
}

export default function ValidationResults({ validation }: ValidationResultsProps) {
  const ResultCard = ({ 
    title, 
    isValid, 
    description, 
    detail 
  }: { 
    title: string; 
    isValid: boolean; 
    description: string; 
    detail?: string; 
  }) => {
    const bgColor = isValid ? "bg-emerald-50" : "bg-red-50";
    const borderColor = isValid ? "border-emerald-200" : "border-red-200";
    const textColor = isValid ? "text-emerald-800" : "text-red-800";
    const iconColor = isValid ? "text-emerald-600" : "text-red-600";
    const detailColor = isValid ? "text-emerald-600" : "text-red-600";

    return (
      <div className={`${bgColor} ${borderColor} border rounded-lg p-4`}>
        <div className="flex items-center justify-between mb-2">
          <h3 className={`text-sm font-medium ${textColor}`}>{title}</h3>
          {isValid ? (
            <CheckCircle className={`w-5 h-5 ${iconColor}`} />
          ) : (
            <XCircle className={`w-5 h-5 ${iconColor}`} />
          )}
        </div>
        <p className={`text-sm ${textColor.replace('800', '700')}`}>{description}</p>
        {detail && (
          <p className={`text-xs ${detailColor} mt-1`}>{detail}</p>
        )}
      </div>
    );
  };

  return (
    <div className="mt-6 grid grid-cols-1 md:grid-cols-4 gap-4">
      <ResultCard
        title="Format Valid"
        isValid={validation.isFormatValid}
        description={validation.isFormatValid ? "Email format is syntactically correct" : "Email format is invalid"}
      />

      <ResultCard
        title="MX Found"
        isValid={validation.hasMxRecord}
        description={validation.hasMxRecord ? "Domain has valid mail servers" : "No mail servers found for domain"}
        detail={validation.mxRecords.length > 0 ? validation.mxRecords.join(", ") : undefined}
      />

      <ResultCard
        title="SMTP Verified"
        isValid={validation.smtpExists}
        description={validation.smtpExists ? "Email address exists on server" : "Email address does not exist"}
      />

      <ResultCard
        title="Valid Email"
        isValid={validation.isValid}
        description={validation.isValid ? "Email passed all validation checks" : validation.errorMessage || "Email failed validation"}
      />
    </div>
  );
}
