import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface BulkEmailValidatorProps {
  onValidation: (validations: any[]) => void;
  setLoading: (loading: boolean) => void;
}

export default function BulkEmailValidator({ onValidation, setLoading }: BulkEmailValidatorProps) {
  const [emailsText, setEmailsText] = useState("");
  const { toast } = useToast();

  const validateBulkEmailsMutation = useMutation({
    mutationFn: async (emails: string[]) => {
      const response = await apiRequest("POST", "/api/validate-bulk-emails", { emails });
      return response.json();
    },
    onSuccess: (data) => {
      onValidation(data.validations);
      setLoading(false);
      const validCount = data.validations.filter((v: any) => v.isValid).length;
      const totalCount = data.validations.length;
      toast({
        title: "Bulk Validation Complete",
        description: `${validCount} of ${totalCount} emails are valid`,
      });
    },
    onError: (error) => {
      setLoading(false);
      toast({
        title: "Validation Failed",
        description: "Failed to validate emails. Please try again.",
        variant: "destructive",
      });
    },
  });

  const emails = emailsText
    .split('\n')
    .map(email => email.trim())
    .filter(email => email.length > 0);

  const handleValidate = () => {
    if (emails.length === 0) {
      toast({
        title: "No Emails Found",
        description: "Please enter at least one email address.",
        variant: "destructive",
      });
      return;
    }

    setLoading(true);
    validateBulkEmailsMutation.mutate(emails);
  };

  return (
    <div className="space-y-4">
      <div>
        <Label htmlFor="bulk-emails" className="block text-sm font-medium text-gray-700 mb-2">
          Email Addresses
        </Label>
        <Textarea
          id="bulk-emails"
          rows={6}
          placeholder="example1@domain.com&#10;example2@domain.com&#10;example3@domain.com"
          value={emailsText}
          onChange={(e) => setEmailsText(e.target.value)}
          className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-colors duration-200 resize-none"
        />
      </div>

      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <Button
          onClick={handleValidate}
          disabled={validateBulkEmailsMutation.isPending}
          className="bg-blue-600 hover:bg-blue-700 text-white font-medium py-3 px-6 rounded-lg transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
        >
          {validateBulkEmailsMutation.isPending ? "Validating..." : "Validate All Emails"}
        </Button>
        <div className="flex items-center text-sm text-gray-600">
          <span>{emails.length} emails</span>
          <span className="mx-2">•</span>
          <span>Ready to validate</span>
        </div>
      </div>
    </div>
  );
}
