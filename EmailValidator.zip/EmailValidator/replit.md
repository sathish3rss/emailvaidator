# Email Validator Application

## Overview

This is a full-stack email validation application built with a modern tech stack. The application provides both single email validation and bulk email validation capabilities, checking email format validity and MX record existence. It features a React frontend with shadcn/ui components and an Express.js backend with PostgreSQL database integration using Drizzle ORM.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Styling**: Tailwind CSS with shadcn/ui component library
- **State Management**: TanStack Query (React Query) for server state management
- **Routing**: Wouter for lightweight client-side routing
- **Build Tool**: Vite for fast development and optimized builds
- **UI Components**: Radix UI primitives with shadcn/ui styling system

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ES modules
- **Database ORM**: Drizzle ORM for type-safe database operations
- **Database**: PostgreSQL (configured for Neon database)
- **Validation**: Zod for schema validation and type safety
- **Session Storage**: PostgreSQL-based session storage

### Key Components

#### Frontend Components
- **Email Validators**: Separate components for single and bulk email validation
- **Validation Results**: Display components for showing validation outcomes
- **UI Components**: Complete shadcn/ui component library including forms, dialogs, tables, and feedback components
- **Loading States**: Custom loading overlay component for async operations

#### Backend Services
- **Email Validation Service**: Core logic for validating email format, MX records, and email realism
- **Storage Layer**: Abstracted storage interface with memory-based implementation
- **API Routes**: RESTful endpoints for email validation operations
- **DNS Resolution**: Built-in MX record checking using Node.js DNS module
- **Smart Validation**: Additional checks for suspicious or unrealistic email patterns

#### Database Schema
- **Email Validations Table**: Stores validation results with fields for email, format validity, MX record status, and validation metadata
- **Audit Trail**: Timestamp tracking for validation history

## Data Flow

1. **Single Email Validation**:
   - User enters email in frontend form
   - Real-time format validation provides immediate feedback
   - On submission, API validates format and checks MX records
   - Results are stored in database and returned to frontend
   - UI displays comprehensive validation results

2. **Bulk Email Validation**:
   - User pastes multiple emails in textarea
   - Frontend parses and validates email list
   - API processes each email asynchronously
   - Results are aggregated and stored
   - Frontend displays summary and detailed results with export options

3. **Validation Logic**:
   - Format validation using RFC-compliant regex patterns
   - MX record lookup using Node.js DNS resolution
   - Smart realism checking to identify suspicious or fake email patterns
   - Enhanced validation for major email providers (Gmail, Yahoo, Outlook, etc.)
   - Comprehensive error handling and detailed reporting
   - Results persistence for audit and analytics

## External Dependencies

### Frontend Dependencies
- **UI Framework**: React ecosystem with TypeScript support
- **Styling**: Tailwind CSS with PostCSS processing
- **Component Library**: Radix UI primitives for accessible components
- **State Management**: TanStack Query for server synchronization
- **Form Handling**: React Hook Form with Zod resolvers
- **Date Utilities**: date-fns for date manipulation

### Backend Dependencies
- **Database**: PostgreSQL with Neon serverless driver
- **ORM**: Drizzle ORM with Drizzle Kit for migrations
- **Validation**: Zod for runtime type checking
- **Session Management**: connect-pg-simple for PostgreSQL session storage
- **DNS Resolution**: Native Node.js DNS module

### Development Tools
- **Build System**: Vite with React plugin and TypeScript support
- **Code Quality**: TypeScript strict mode configuration
- **Development Experience**: Replit-specific plugins for enhanced development

## Deployment Strategy

### Production Build
- **Frontend**: Vite builds optimized static assets to `dist/public`
- **Backend**: esbuild bundles server code to `dist/index.js`
- **Database**: Drizzle migrations manage schema changes

### Environment Configuration
- **Development**: Hot module replacement with Vite dev server
- **Production**: Express serves static files and API routes
- **Database**: PostgreSQL connection via environment variable
- **Sessions**: PostgreSQL-backed session storage

### Scalability Considerations
- **Database**: Connection pooling through Neon serverless
- **Caching**: Query client configuration for optimal data fetching
- **Error Handling**: Comprehensive error boundaries and API error responses
- **Performance**: Optimized bundle splitting and lazy loading capabilities

The application is designed for easy deployment on cloud platforms with PostgreSQL support, featuring environment-based configuration and production-ready build processes.