import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const emailValidations = pgTable("email_validations", {
  id: serial("id").primaryKey(),
  email: text("email").notNull(),
  isFormatValid: boolean("is_format_valid").notNull(),
  hasMxRecord: boolean("has_mx_record").notNull(),
  mxRecords: text("mx_records").array(),
  smtpExists: boolean("smtp_exists"),
  isValid: boolean("is_valid").notNull(),
  errorMessage: text("error_message"),
  validatedAt: timestamp("validated_at").defaultNow().notNull(),
});

export const insertEmailValidationSchema = createInsertSchema(emailValidations).omit({
  id: true,
  validatedAt: true,
});

export const validateEmailRequestSchema = z.object({
  email: z.string().email("Invalid email format"),
});

export const validateBulkEmailsRequestSchema = z.object({
  emails: z.array(z.string().email("Invalid email format")),
});

export type InsertEmailValidation = z.infer<typeof insertEmailValidationSchema>;
export type EmailValidation = typeof emailValidations.$inferSelect;
export type ValidateEmailRequest = z.infer<typeof validateEmailRequestSchema>;
export type ValidateBulkEmailsRequest = z.infer<typeof validateBulkEmailsRequestSchema>;
